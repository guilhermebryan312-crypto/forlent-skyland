# Forlent Sky Native 6.0.0

Projeto Android nativo Kotlin, sem AutoJS.

## O que esta base já implementa
- Interface escura adaptada para celular.
- Contadores manuais de partidas e baús.
- Cronômetro de sessão com pausa/retomada e timer opcional.
- Configurações persistidas localmente.
- Registro manual de itens e histórico local.
- Envio de embeds ao Discord por webhook.
- Workflow GitHub Actions para gerar APK debug.

## Limites desta migração
Esta versão não executa toques automáticos, macros de gameplay, anti-AFK ou saída automática de partidas. Também não inclui ainda captura de tela/OCR nem overlay flutuante real. Esses recursos precisam de implementação Android específica e permissões explícitas; esta base não os declara como concluídos.

## Compilar
Envie o conteúdo deste ZIP para a raiz do repositório GitHub e execute Actions > Build Forlent Sky Native APK > Run workflow. O artefato será `ForlentSky-Native-6.0.0`.

Package: `com.forlent.sky`
Version: `6.0.0` (60)
