plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.forlent.sky"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.forlent.sky"
        minSdk = 26
        targetSdk = 35
        versionCode = 60
        versionName = "6.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
