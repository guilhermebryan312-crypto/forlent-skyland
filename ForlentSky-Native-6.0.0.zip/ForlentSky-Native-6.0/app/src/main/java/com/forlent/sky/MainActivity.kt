package com.forlent.sky

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(14, 18, 22)
    private val panel = Color.rgb(27, 34, 40)
    private val mint = Color.rgb(78, 204, 163)
    private val muted = Color.rgb(160, 170, 180)
    private val prefs by lazy { getSharedPreferences("forlent_sky", MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    private var running = false
    private var sessionStart = 0L
    private var elapsedBefore = 0L
    private var matches = 0
    private var chests = 0
    private var lastItem = "Nenhum"
    private var timerEnabled = false
    private var timerSeconds = 600
    private var maxMatches = 0
    private var webhook = ""
    private val logs = mutableListOf<String>()

    private lateinit var timeValue: TextView
    private lateinit var matchValue: TextView
    private lateinit var chestValue: TextView
    private lateinit var itemValue: TextView
    private lateinit var statusValue: TextView
    private lateinit var logBox: TextView
    private lateinit var startButton: Button
    private lateinit var timerCheck: CheckBox
    private lateinit var timerInput: EditText
    private lateinit var maxInput: EditText
    private lateinit var webhookInput: EditText

    private val ticker = object : Runnable {
        override fun run() {
            refreshStats()
            if (running) handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadState()
        buildUi()
        refreshStats()
        addLog("Forlent Sky 6.0.0 iniciado.")
    }

    private fun loadState() {
        matches = prefs.getInt("matches", 0)
        chests = prefs.getInt("chests", 0)
        lastItem = prefs.getString("lastItem", "Nenhum") ?: "Nenhum"
        elapsedBefore = prefs.getLong("elapsed", 0L)
        timerEnabled = prefs.getBoolean("timerEnabled", false)
        timerSeconds = prefs.getInt("timerSeconds", 600)
        maxMatches = prefs.getInt("maxMatches", 0)
        webhook = prefs.getString("webhook", "") ?: ""
        val rawLogs = prefs.getString("logs", "") ?: ""
        if (rawLogs.isNotBlank()) logs.addAll(rawLogs.split("\n").takeLast(40))
    }

    private fun saveState() {
        prefs.edit()
            .putInt("matches", matches)
            .putInt("chests", chests)
            .putString("lastItem", lastItem)
            .putLong("elapsed", currentElapsed())
            .putBoolean("timerEnabled", timerEnabled)
            .putInt("timerSeconds", timerSeconds)
            .putInt("maxMatches", maxMatches)
            .putString("webhook", webhook)
            .putString("logs", logs.takeLast(40).joinToString("\n"))
            .apply()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = text("🏴‍☠️ FORLENT SKY", 25f, Color.WHITE, true)
        title.gravity = Gravity.CENTER
        root.addView(title, matchWrap())
        val subtitle = text("GALAXY A07 EDITION  •  VERSION 6.0.0", 11f, mint, true)
        subtitle.gravity = Gravity.CENTER
        root.addView(subtitle, matchWrap().apply { topMargin = dp(5); bottomMargin = dp(18) })

        val statusCard = card()
        statusValue = text("●  PRONTO", 13f, mint, true)
        statusCard.addView(statusValue)
        root.addView(statusCard, matchWrap().apply { bottomMargin = dp(10) })

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        matchValue = statCard(stats, "PARTIDAS", matches.toString(), mint)
        chestValue = statCard(stats, "BAÚS", chests.toString(), Color.rgb(241, 196, 15))
        root.addView(stats, matchWrap().apply { bottomMargin = dp(10) })

        val timeCard = card()
        timeCard.addView(text("TEMPO DE SESSÃO", 11f, muted, true))
        timeValue = text("00:00:00", 28f, Color.WHITE, true)
        timeCard.addView(timeValue)
        timeCard.addView(text("Último item identificado", 11f, muted, false).apply {
            setPadding(0, dp(10), 0, dp(3))
        })
        itemValue = text(lastItem, 15f, mint, true)
        timeCard.addView(itemValue)
        root.addView(timeCard, matchWrap().apply { bottomMargin = dp(10) })

        val actions = card()
        actions.addView(sectionTitle("CONTROLES DA SESSÃO"))
        startButton = button(if (running) "PAUSAR SESSÃO" else "INICIAR SESSÃO", mint)
        startButton.setOnClickListener { toggleSession() }
        actions.addView(startButton, matchWrap())
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("+ PARTIDA", panel) { matches++; saveState(); refreshStats(); addLog("Partida registrada manualmente.") },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(5); topMargin = dp(8) })
        row.addView(button("+ BAÚ", panel) { chests++; saveState(); refreshStats(); addLog("Baú registrado manualmente.") },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(5); topMargin = dp(8) })
        actions.addView(row)
        actions.addView(button("REGISTRAR ITEM", panel) { showItemDialog() }, matchWrap().apply { topMargin = dp(8) })
        actions.addView(button("ZERAR ESTATÍSTICAS", panel) { confirmReset() }, matchWrap().apply { topMargin = dp(8) })
        root.addView(actions, matchWrap().apply { bottomMargin = dp(10) })

        val settings = card()
        settings.addView(sectionTitle("CONFIGURAÇÕES"))
        settings.addView(text("Limite de partidas (0 = sem limite)", 12f, muted, false))
        maxInput = edit(maxMatches.toString(), InputType.TYPE_CLASS_NUMBER)
        settings.addView(maxInput, matchWrap())
        timerCheck = CheckBox(this).apply {
            text = "Ativar timer de sessão"
            setTextColor(Color.WHITE)
            isChecked = timerEnabled
            buttonTintList = android.content.res.ColorStateList.valueOf(mint)
        }
        settings.addView(timerCheck, matchWrap())
        timerInput = edit(timerSeconds.toString(), InputType.TYPE_CLASS_NUMBER)
        timerInput.isEnabled = timerEnabled
        timerCheck.setOnCheckedChangeListener { _, checked -> timerInput.isEnabled = checked }
        settings.addView(timerInput, matchWrap())
        settings.addView(text("Webhook do Discord (opcional)", 12f, muted, false).apply {
            setPadding(0, dp(10), 0, dp(4))
        })
        webhookInput = edit(webhook, InputType.TYPE_TEXT_VARIATION_URI)
        webhookInput.hint = "https://discord.com/api/webhooks/..."
        settings.addView(webhookInput, matchWrap())
        settings.addView(button("SALVAR CONFIGURAÇÕES", panel) { saveSettings() },
            matchWrap().apply { topMargin = dp(8) })
        settings.addView(button("TESTAR WEBHOOK", panel) { saveSettings(); sendDiscord("Forlent Sky conectado", "Teste de conexão enviado pelo Forlent Sky 6.0.0.", 0x4ECCA3) },
            matchWrap().apply { topMargin = dp(8) })
        root.addView(settings, matchWrap().apply { bottomMargin = dp(10) })

        val logCard = card()
        logCard.addView(sectionTitle("REGISTROS RECENTES"))
        logBox = text("", 11f, muted, false)
        logBox.setTextIsSelectable(true)
        logCard.addView(logBox)
        logCard.addView(button("LIMPAR REGISTROS", panel) { logs.clear(); addLog("Registros limpos.") },
            matchWrap().apply { topMargin = dp(8) })
        root.addView(logCard, matchWrap())

        if (running) {
            startButton.text = "PAUSAR SESSÃO"
            handler.post(ticker)
        }
    }

    private fun statCard(parent: LinearLayout, label: String, value: String, color: Int): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(8), dp(14))
            setBackgroundColor(panel)
        }
        box.addView(text(label, 10f, muted, true))
        val valueView = text(value, 25f, color, true)
        box.addView(valueView)
        parent.addView(box, LinearLayout.LayoutParams(0, dp(82), 1f).apply {
            if (label == "PARTIDAS") rightMargin = dp(5) else leftMargin = dp(5)
        })
        return valueView
    }

    private fun toggleSession() {
        if (!running) {
            saveSettings()
            if (maxMatches > 0 && matches >= maxMatches) {
                toast("Limite de partidas já atingido.")
                return
            }
            running = true
            sessionStart = System.currentTimeMillis()
            statusValue.text = "●  SESSÃO ATIVA"
            statusValue.setTextColor(mint)
            startButton.text = "PAUSAR SESSÃO"
            addLog("Sessão iniciada.")
            sendDiscord("Sessão iniciada", "Monitoramento manual iniciado.", 0x3498DB)
            handler.removeCallbacks(ticker)
            handler.post(ticker)
        } else {
            running = false
            elapsedBefore = currentElapsed()
            statusValue.text = "●  PAUSADO"
            statusValue.setTextColor(Color.rgb(241, 196, 15))
            startButton.text = "RETOMAR SESSÃO"
            handler.removeCallbacks(ticker)
            addLog("Sessão pausada.")
            saveState()
        }
        refreshStats()
    }

    private fun saveSettings() {
        maxMatches = maxInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
        timerEnabled = timerCheck.isChecked
        timerSeconds = timerInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 600
        webhook = webhookInput.text.toString().trim()
        saveState()
        addLog("Configurações salvas.")
        toast("Configurações salvas.")
    }

    private fun showItemDialog() {
        val input = EditText(this).apply {
            hint = "Nome do item"
            setText(lastItem.takeUnless { it == "Nenhum" } ?: "")
        }
        AlertDialog.Builder(this)
            .setTitle("Registrar item")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Registrar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    lastItem = name
                    chests++
                    itemValue.text = lastItem
                    refreshStats()
                    addLog("Item registrado: $name")
                    sendDiscord("Item registrado: $name", "Baús registrados: $chests\nPartidas: $matches", 0xF1C40F)
                    saveState()
                }
            }.show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this).setTitle("Zerar estatísticas?")
            .setMessage("Isso apaga as contagens e o tempo acumulado desta instalação.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Zerar") { _, _ ->
                matches = 0; chests = 0; lastItem = "Nenhum"; elapsedBefore = 0
                saveState(); refreshStats(); addLog("Estatísticas zeradas.")
            }.show()
    }

    private fun refreshStats() {
        if (!::timeValue.isInitialized) return
        matchValue.text = matches.toString()
        chestValue.text = chests.toString()
        itemValue.text = lastItem
        val sec = currentElapsed() / 1000
        timeValue.text = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
        logBox.text = logs.takeLast(12).asReversed().joinToString("\n")
        if (running && timerEnabled && sec >= timerSeconds) {
            running = false
            elapsedBefore = currentElapsed()
            handler.removeCallbacks(ticker)
            statusValue.text = "●  TIMER CONCLUÍDO"
            statusValue.setTextColor(Color.rgb(241, 196, 15))
            startButton.text = "INICIAR SESSÃO"
            addLog("Timer concluído; sessão pausada.")
            sendDiscord("Timer concluído", "A sessão foi pausada pelo timer configurado.", 0xF39C12)
            saveState()
        }
    }

    private fun currentElapsed(): Long =
        elapsedBefore + if (running) System.currentTimeMillis() - sessionStart else 0L

    private fun addLog(message: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs.add("[$stamp] $message")
        while (logs.size > 40) logs.removeAt(0)
        if (::logBox.isInitialized) refreshStats()
        saveState()
    }

    private fun sendDiscord(title: String, description: String, color: Int) {
        val target = webhook
        if (target.isBlank()) {
            addLog("Webhook não configurado; notificação ignorada.")
            return
        }
        if (!target.startsWith("https://discord.com/api/webhooks/")) {
            addLog("Webhook inválido: use um endereço oficial do Discord.")
            return
        }
        worker.execute {
            var connection: HttpURLConnection? = null
            try {
                val embed = JSONObject()
                    .put("title", title)
                    .put("description", description)
                    .put("color", color)
                    .put("timestamp", java.time.Instant.now().toString())
                    .put("footer", JSONObject().put("text", "Forlent Sky 6.0.0"))
                val payload = JSONObject().put("embeds", JSONArray().put(embed))
                connection = (URL(target).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10000
                    readTimeout = 10000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                handler.post { addLog(if (code == 204 || code == 200) "Discord: envio concluído." else "Discord: resposta HTTP $code.") }
            } catch (e: Exception) {
                handler.post { addLog("Discord: falha de conexão (${e.javaClass.simpleName}).") }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        setBackgroundColor(panel)
    }

    private fun sectionTitle(value: String) = text(value, 12f, mint, true).apply {
        setPadding(0, 0, 0, dp(10))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
        }

    private fun edit(value: String, type: Int) = EditText(this).apply {
        setSingleLine(true)
        setText(value)
        inputType = type
        textSize = 14f
        setTextColor(Color.WHITE)
        setHintTextColor(muted)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setBackgroundColor(Color.rgb(40, 48, 55))
    }

    private fun button(label: String, color: Int, action: (() -> Unit)? = null) =
        Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(if (color == mint) Color.rgb(10, 25, 20) else Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            if (action != null) setOnClickListener { action() }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onPause() {
        saveState()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        worker.shutdown()
        saveState()
        super.onDestroy()
    }
}
